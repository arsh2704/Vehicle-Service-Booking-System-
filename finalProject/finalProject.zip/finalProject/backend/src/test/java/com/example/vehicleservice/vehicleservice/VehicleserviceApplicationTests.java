package com.example.vehicleservice.vehicleservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
